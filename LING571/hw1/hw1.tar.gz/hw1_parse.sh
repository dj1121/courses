#!/bin/sh
python hw1_parse.py $@