#!/bin/sh
python3 hw8.py $1 $2 $3 $4