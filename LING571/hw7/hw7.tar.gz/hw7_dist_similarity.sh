#!/bin/sh
python3 hw7.py $1 $2 $3 $4