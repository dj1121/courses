#!/bin/sh
python3 hw7_cbow.py $1 $2 $3