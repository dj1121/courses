#!/bin/sh
python3 hw9.py $1 $2 $3