#!/bin/sh
python3 cky.py $1 $2 $3