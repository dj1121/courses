#!/bin/sh
python3 hw6_semantics.py $1 $2 $3