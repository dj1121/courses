#!/bin/sh
python cnf_converter.py $1 $2