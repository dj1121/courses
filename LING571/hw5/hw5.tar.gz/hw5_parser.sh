#!/bin/sh
python3 hw5_parse.py $1 $2 $3